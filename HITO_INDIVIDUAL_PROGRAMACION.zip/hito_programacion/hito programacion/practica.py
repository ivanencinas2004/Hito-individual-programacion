print('Bienvenido a nuestra empresa')
print('A continuacion debe rellenar los siguientes datos')

class Empresa():
        def __init__(self) -> None:
            self.nombre=input('Escriba su nombre ')
            self.apellidos=input('Escriba sus apellidos ')
            self.numero=int(input('Escriba su numero de telefono '))
            self.direccion=input('Escriba su direccion de correo ')
            self.dni=input('Escriba su DNI ')


        def conmfirmaRegistro(self):
            print(f'Tus datos se han guardado correctamente {self.nombre} ')

    
        def compra(self):
            productos=['mancuernas', 'barra', 'banco', 'esterilla']
            precios=[35, 120, 200, 15]
            listafinal=[]
            while True:
                numero=input('''
                1. añadir producto al carrito 
                2. mostrar el precio total
                3. finalizar compra

                Seleccione la opcion que quiera ''')
                
                if  numero== '1':
                    print(productos)
                    nombre=input('dime que producto quieres ').lower()
                    if nombre in productos:
                        catalogo=productos.index(nombre)
                        precio=precios[catalogo]
                        print(f'el precio del produto que has seleccionado es {precio}')
                        listafinal.append(precio)
                    else:
                        print('El producto no esta disponible, porfavor vuelva a seleccionar otro producto')   

                elif numero=='2':
                    precioTotal=sum(listafinal)
                    print(f'el precio total es {precioTotal}')
                    
                elif numero=='3':

                    precioTotal=sum(listafinal)
                    pais=input('De que pais eres ').lower()
                    if pais=='españa':
                        print('el iva en España es del 21%')
                        precioTotalIva=precioTotal*1.21
                        print(f'el precio total en españa es de {precioTotalIva}')
                    else:
                        print(f'el iva en {pais}es del 8%')
                        precioTotalIva=precioTotal*1.08
                        print(f'Por lo tanto el precio total de su compra en {pais} es de {precioTotalIva}')

                    DNI=input('Para confirmar tu pedido escriba su DNI ') 
                    if DNI==self.dni:
                        print(f'Su compra ha sido realizada correctamente y su precio es {precioTotalIva}')
                        print(f'Se ha enviado un pdf de la factura al correo {self.direccion}') 
                        print(f'El seguimiento de su pedido lo podra hacer en el telefono {self.numero} y el correo {self.direccion}')       
                        break
                    else:
                        print('DNI incorrecto')
                        input('Por favor escriba de nuevo su DNI ')
                        if DNI==self.dni:
                            print(f'Su compra ha sido realizada correctamente y su precio es {precioTotalIva}')
                            print(f'Se ha enviado un pdf de la factura al correo {self.direccion}') 
                            print(f'El seguimiento de su pedido lo podra hacer en el telefono {self.numero} y el correo {self.direccion}')       
                        else:
                            print('DNI incorrecto repita la operacion')
                    

                    


cliente1=Empresa()
cliente1.conmfirmaRegistro()
cliente1.compra()